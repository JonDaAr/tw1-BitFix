package com.tallerwebi.dominio;

import com.tallerwebi.dominio.excepcion.DatosIncompletosException;
import com.tallerwebi.dominio.excepcion.FechaEntregaNoDefinidaException;
import com.tallerwebi.dominio.excepcion.NoHayTecnicosDisponibles;
import com.tallerwebi.dominio.excepcion.PedidoNoEncontradoException;
import com.tallerwebi.presentacion.DatosCotizacionOnline;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("ServicioOrdenReparacion")
@Transactional
public class ServicioOrdenReparacionImpl implements ServicioOrdenReparacion {

  private final RepositorioOrdenReparacion repositorioOrdenReparacion;
  private final RepositorioUsuario repositorioUsuario;

  @Autowired
  public ServicioOrdenReparacionImpl(
    RepositorioUsuario repositorioUsuario,
    RepositorioOrdenReparacion repositorioOrdenReparacion
  ) {
    this.repositorioUsuario = repositorioUsuario;
    this.repositorioOrdenReparacion = repositorioOrdenReparacion;
  }

  @Override
  public OrdenReparacion registrarOrden(OrdenReparacion orden)
    throws DatosIncompletosException, NoHayTecnicosDisponibles {
    validarOrden(orden);

    if (orden.getCodigoSeguimiento() == null) {
      orden.generarCodigoSeguimientoUnico();
    }

    if (orden.getEstado() == null) {
      orden.setEstado(EstadoOrden.REPARADO);
    }

    asignarTecnicoAOrden(orden);

    this.repositorioOrdenReparacion.guardarOrden(orden);

    return orden;
  }

  @Override
  public OrdenReparacion consultarEstado(Integer codigo) throws PedidoNoEncontradoException {
    if (codigo == null) {
      throw new PedidoNoEncontradoException("El código no puede estar vacío");
    }

    OrdenReparacion orden = repositorioOrdenReparacion.buscarPorCodigo(codigo);
    if (orden == null) {
      throw new PedidoNoEncontradoException("No se encontró ningún pedido con el código ingresado");
    }
    return orden;
  }

  private void validarOrden(OrdenReparacion orden) throws DatosIncompletosException {
    if (
      orden == null ||
      esCadenaVacia(orden.getNombreCliente()) ||
      esCadenaVacia(orden.getEmailCliente()) ||
      esCadenaVacia(orden.getModeloEquipo()) ||
      esCadenaVacia(orden.getDescripcionFalla())
    ) {
      throw new DatosIncompletosException();
    }
  }

  private void asignarTecnicoAOrden(OrdenReparacion orden) {
    // 1. Traemos a todos los técnicos activos
    List<Usuario> tecnicos = repositorioUsuario.buscarTecnicosActivos();
    if (tecnicos.isEmpty()) {
      throw new NoHayTecnicosDisponibles();
    }

    // 2. Filtramos la lista para quedarnos SOLO con los que tengan el mismo nivel de la orden
    List<Usuario> tecnicosFiltrados = tecnicos
      .stream()
      .filter(tecnico -> tecnico.getNivelSoporte() == orden.getNivelReparacion())
      .collect(Collectors.toList());

    // 3. Si no hay ningún técnico de ese nivel específico, lanzamos la excepción
    if (tecnicosFiltrados.isEmpty()) {
      throw new NoHayTecnicosDisponibles();
    }

    // 4. Aplicamos tu algoritmo de menor cantidad de órdenes sobre la lista ya filtrada
    Usuario tecnicoSeleccionado = seleccionarTecnico(tecnicosFiltrados);
    orden.setTecnicoAsignado(tecnicoSeleccionado);
    orden.setFechaAsignacion(LocalDateTime.now());
  }

  private boolean esCadenaVacia(String texto) {
    return texto == null || texto.trim().isEmpty();
  }

  private Usuario seleccionarTecnico(List<Usuario> tecnicos) {
    Usuario seleccionado = tecnicos.get(0);
    long menorCantidad = repositorioOrdenReparacion.contarOrdenesActivas(seleccionado.getId());
    LocalDateTime ultimaAsignacion = repositorioOrdenReparacion.buscarFechaUltimaAsignacion(
      seleccionado.getId()
    );

    for (int i = 1; i < tecnicos.size(); i++) {
      Usuario candidato = tecnicos.get(i);
      long cantidad = repositorioOrdenReparacion.contarOrdenesActivas(candidato.getId());
      LocalDateTime ultimaAsignacionCandidato =
        repositorioOrdenReparacion.buscarFechaUltimaAsignacion(candidato.getId());

      if (debeSeleccionarse(cantidad, ultimaAsignacionCandidato, menorCantidad, ultimaAsignacion)) {
        seleccionado = candidato;
        menorCantidad = cantidad;
        ultimaAsignacion = ultimaAsignacionCandidato;
      }
    }

    return seleccionado;
  }

  private boolean debeSeleccionarse(
    long cantidadCandidato,
    LocalDateTime ultimaAsignacionCandidato,
    long menorCantidad,
    LocalDateTime ultimaAsignacionSeleccionado
  ) {
    if (cantidadCandidato < menorCantidad) {
      return true;
    }
    if (cantidadCandidato > menorCantidad) {
      return false;
    }
    if (ultimaAsignacionSeleccionado == null) {
      return false;
    }
    return (
      ultimaAsignacionCandidato == null ||
      ultimaAsignacionCandidato.isBefore(ultimaAsignacionSeleccionado)
    );
  }

  @Override
  public List<OrdenReparacion> obtenerOrdenesParaTecnico() {
    List<OrdenReparacion> listaOrdenes = new ArrayList<>(repositorioOrdenReparacion.buscarTodas());
    ordenarLista(listaOrdenes);
    return listaOrdenes;
  }

  private void ordenarLista(List<OrdenReparacion> listaOrdenes) {
    listaOrdenes.sort((a, b) -> {
      boolean aEntregada = a.getEstado() == EstadoOrden.ENTREGADO;
      boolean bEntregada = b.getEstado() == EstadoOrden.ENTREGADO;

      if (aEntregada && bEntregada) {
        if (a.getFechaEntrega() == null || b.getFechaEntrega() == null) {
          throw new FechaEntregaNoDefinidaException("La orden entregada no tiene fecha de entrega");
        }
        return a.getFechaEntrega().compareTo(b.getFechaEntrega());
      }
      if (aEntregada) {
        return 1;
      }
      if (bEntregada) {
        return -1;
      }
      int porPrioridad = a.getPrioridad().compareTo(b.getPrioridad());
      if (porPrioridad != 0) {
        return porPrioridad;
      }
      return a.getFechaIngreso().compareTo(b.getFechaIngreso());
    });
  }

  @Override
  public List<OrdenReparacion> obtenerOrdenesDelCliente(String email) {
    return repositorioOrdenReparacion.buscarPorEmailCliente(email);
  }

  @Override
  public List<OrdenReparacion> obtenerOrdenesDelTecnico(Long tecnicoId) {
    return repositorioOrdenReparacion.buscarPorTecnico(tecnicoId);
  }

  //--------------Gestion estado y diagnostico("nota tecnica")
  @Override
  public List<OrdenReparacion> listarTodas() {
    return repositorioOrdenReparacion.listarTodasLasOrdenes();
  }

  @Override
  public OrdenReparacion buscarPorId(Long idOrden) {
    return repositorioOrdenReparacion.buscarPorId(idOrden);
  }

  @Override
  public void actualizarEstadoYNotaTecnica(
    Long idOrdenReparacion,
    EstadoOrden nuevoEstado,
    String notaTecnica
  ) {
    OrdenReparacion ordenSeleccionada = repositorioOrdenReparacion.buscarPorId(idOrdenReparacion);

    ordenSeleccionada.setEstado(nuevoEstado);

    // SI PASA A ENTREGADO, GUARDAMOS LA FECHA ACTUAL
    if (nuevoEstado == EstadoOrden.ENTREGADO) {
      ordenSeleccionada.setFechaEntrega(LocalDateTime.now());
    }

    if (notaTecnica != null && !notaTecnica.isEmpty()) {
      ordenSeleccionada.setNotaTecnica(notaTecnica);
    }
  }

  @Override
  public List<EstadoOrden> obtenerEstadosPermitidosPara(EstadoOrden estadoActual) {
    List<EstadoOrden> permitidos = new ArrayList<>();
    permitidos.add(estadoActual);

    ofrecerEstadosParaFlujoCotizacionOnline(estadoActual, permitidos);
    ofrecerEstadosParaFlujoRecepcionTaller(estadoActual, permitidos);

    return permitidos;
  }

  private void ofrecerEstadosParaFlujoCotizacionOnline(
    EstadoOrden estadoActual,
    List<EstadoOrden> permitidos
  ) {
    switch (estadoActual) {
      // Flujo Cotizacion Online
      case SOLICITUD_COTIZACION: // El cliente inicia solicitando cotizacion online
        permitidos.add(EstadoOrden.COTIZACION_PREVIA_ENVIADA);
        break;
      case COTIZACION_PREVIA_ENVIADA: // El tecnico responde y cambia a este estado
        permitidos.add(EstadoOrden.ESPERANDO_INGRESO);
        permitidos.add(EstadoOrden.COTIZACION_DESCARTADA);
        break;
      case ESPERANDO_INGRESO: // Cliente acepta la cotizacion y debe llevar el equipo al taller para esperar el presupuesto final
        permitidos.add(EstadoOrden.RECIBIDO); // El tecnico lo recibe y se conecta con el flujo tradicional
        break;
      case COTIZACION_DESCARTADA:
        break; // El cliente rechazo la cotizacion y no va a llevar el equipo a reparar
      default:
        break;
    }
  }

  private void ofrecerEstadosParaFlujoRecepcionTaller(
    EstadoOrden estadoActual,
    List<EstadoOrden> permitidos
  ) {
    switch (estadoActual) {
      // Flujo tradicional - recepcion en el taller
      case RECIBIDO:
        permitidos.add(EstadoOrden.EN_DIAGNOSTICO);
        break;
      case EN_DIAGNOSTICO:
        permitidos.add(EstadoOrden.ESPERANDO_REPUESTO);
        permitidos.add(EstadoOrden.REPARADO);
        break;
      case PRESUPUESTO_ACEPTADO:
        permitidos.add(EstadoOrden.EN_REPARACION);
        permitidos.add(EstadoOrden.ESPERANDO_REPUESTO);
        break;
      case EN_REPARACION:
        permitidos.add(EstadoOrden.REPARADO);
        permitidos.add(EstadoOrden.ESPERANDO_REPUESTO);
        break;
      case ESPERANDO_REPUESTO:
        permitidos.add(EstadoOrden.REPARADO);
        permitidos.add(EstadoOrden.EN_REPARACION);
        break;
      case REPARADO:
        permitidos.add(EstadoOrden.ENTREGADO);
        break;
      case ENTREGADO:
        break;
      default:
        break;
    }
  }

  @Override
  public void aceptarPresupuesto(Integer codigoSeguimiento, String emailUsuario) {
    OrdenReparacion orden = repositorioOrdenReparacion.buscarPorCodigo(codigoSeguimiento);

    if (orden == null) {
      throw new IllegalArgumentException("No se encontró la orden.");
    }

    // Validar IDOR
    if (!orden.getEmailCliente().equals(emailUsuario)) {
      throw new SecurityException("Acceso denegado.");
    }

    //Validar máquina de estados
    if (orden.getEstado() != EstadoOrden.PRESUPUESTO_ENVIADO) {
      throw new IllegalStateException(
        "El presupuesto no se puede aceptar en el estado actual: " + orden.getEstado()
      );
    }

    orden.setEstado(EstadoOrden.PRESUPUESTO_ACEPTADO);
    repositorioOrdenReparacion.modificarOrden(orden);
  }

  @Override
  public void rechazarPresupuesto(Integer codigoSeguimiento, String emailUsuario) {
    OrdenReparacion orden = repositorioOrdenReparacion.buscarPorCodigo(codigoSeguimiento);

    if (orden == null) {
      throw new IllegalArgumentException("No se encontró la orden.");
    }

    if (!orden.getEmailCliente().equals(emailUsuario)) {
      throw new SecurityException("Acceso denegado.");
    }

    //Validar máquina de estados
    if (orden.getEstado() != EstadoOrden.PRESUPUESTO_ENVIADO) {
      throw new IllegalStateException(
        "El presupuesto no se puede rechazar en el estado actual: " + orden.getEstado()
      );
    }

    orden.setEstado(EstadoOrden.PRESUPUESTO_RECHAZADO);
    repositorioOrdenReparacion.modificarOrden(orden);
  }

  //Para Implementar Historial del Tecnico
  @Override
  public List<OrdenReparacion> obtenerHistorialDelTecnico(Long idTecnico) {
    return repositorioOrdenReparacion.buscarOrdenesCompletadasPorTecnico(idTecnico);
  }

  @Override
  public OrdenReparacion registrarCotizacionOnline(DatosCotizacionOnline datosCotizacion)
    throws DatosIncompletosException {
    // Valida que no lleguen campos vacios
    if (
      datosCotizacion == null ||
      esCadenaVacia(datosCotizacion.getNombreCliente()) ||
      esCadenaVacia(datosCotizacion.getEmailCliente()) ||
      esCadenaVacia(datosCotizacion.getModeloEquipo()) ||
      esCadenaVacia(datosCotizacion.getDescripcionFalla())
    ) {
      throw new DatosIncompletosException();
    }

    //Mapea DTO a Entidad
    OrdenReparacion nuevaOrden = new OrdenReparacion();
    nuevaOrden.setNombreCliente(datosCotizacion.getNombreCliente());
    nuevaOrden.setEmailCliente(datosCotizacion.getEmailCliente());
    nuevaOrden.setModeloEquipo(datosCotizacion.getModeloEquipo());
    nuevaOrden.setDescripcionFalla(datosCotizacion.getDescripcionFalla());

    nuevaOrden.setEstado(EstadoOrden.SOLICITUD_COTIZACION);
    nuevaOrden.generarCodigoSeguimientoUnico();
    asignarTecnicoAOrden(nuevaOrden);

    this.repositorioOrdenReparacion.guardarOrden(nuevaOrden);

    return nuevaOrden;
  }

  @Override
  public void reasignarOrden(Long idOrden, Long idNuevoTecnico) {
    OrdenReparacion orden = repositorioOrdenReparacion.buscarPorId(idOrden);
    Usuario nuevoTecnico = repositorioUsuario.buscarPorId(idNuevoTecnico);

    if (orden == null || nuevoTecnico == null) {
      throw new IllegalArgumentException("Datos inválidos para la reasignación.");
    }

    // Hacemos el cambio de manos y reseteamos la fecha para el balanceo de carga
    orden.setTecnicoAsignado(nuevoTecnico);
    orden.setFechaAsignacion(LocalDateTime.now());

    repositorioOrdenReparacion.modificarOrden(orden);
  }
}
