package com.tallerwebi.dominio;

import com.tallerwebi.dominio.excepcion.SinStockException;
import com.tallerwebi.presentacion.ItemPresupuestoForm;
import java.util.List;

public interface ServicioPresupuesto {
  List<Repuesto> obtenerRepuestosDisponibles();

  Double calcularSubtotal(Long repuestoId, Integer cantidad) throws SinStockException;

  Double calcularSubtotalRepuesto(Long repuestoId, Integer cantidad) throws SinStockException;

  void descontarStockRepuesto(Long repuestoId, Integer cantidad) throws SinStockException;

  //areglar metodo no se usa en el controlador
  Double calcularTotalPresupuesto(List<ItemPresupuestoForm> items) throws SinStockException;

  void enviarPresupuesto(Integer codigoSeguimiento, List<ItemPresupuestoForm> items, Double total);

  Double calcularManoDeObra(Double subtotalRepuestos);

  Double calcularSubtotalRepuestos(List<ItemPresupuestoForm> items) throws SinStockException;
}
