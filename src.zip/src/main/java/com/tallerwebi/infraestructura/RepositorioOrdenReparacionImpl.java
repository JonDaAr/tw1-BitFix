package com.tallerwebi.infraestructura;

import com.tallerwebi.dominio.EstadoOrden;
import com.tallerwebi.dominio.OrdenReparacion;
import com.tallerwebi.dominio.RepositorioOrdenReparacion;
import java.time.LocalDateTime;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("repositorioOrden")
public class RepositorioOrdenReparacionImpl implements RepositorioOrdenReparacion {

  private static final String FROM_ORDEN_REPARACION = "from OrdenReparacion o ";

  private final SessionFactory sessionFactory;

  @Autowired
  public RepositorioOrdenReparacionImpl(SessionFactory sessionFactory) {
    this.sessionFactory = sessionFactory;
  }

  @Override
  public void guardarOrden(OrdenReparacion orden) {
    sessionFactory.getCurrentSession().persist(orden);
  }

  @Override
  public OrdenReparacion buscarPorCodigo(Integer codigoSeguimiento) {
    return sessionFactory
      .getCurrentSession()
      .createQuery(
        FROM_ORDEN_REPARACION + "where o.codigoSeguimiento = :codigoSeguimiento",
        OrdenReparacion.class
      )
      .setParameter("codigoSeguimiento", codigoSeguimiento)
      .uniqueResult();
  }

  @Override
  public OrdenReparacion buscarPorId(Long id) {
    return sessionFactory.getCurrentSession().get(OrdenReparacion.class, id);
  }

  @Override
  public void modificarOrden(OrdenReparacion orden) {
    sessionFactory.getCurrentSession().merge(orden);
  }

  @Override
  public long contarOrdenesActivas(Long tecnicoId) {
    return sessionFactory
      .getCurrentSession()
      .createQuery(
        "select count(o) " +
        "from OrdenReparacion o " +
        "where o.tecnicoAsignado.id = :tecnicoId " +
        "and o.estado <> :estadoEntregado",
        Long.class
      )
      .setParameter("tecnicoId", tecnicoId)
      .setParameter("estadoEntregado", EstadoOrden.ENTREGADO)
      .uniqueResult();
  }

  @Override
  public LocalDateTime buscarFechaUltimaAsignacion(Long tecnicoId) {
    return sessionFactory
      .getCurrentSession()
      .createQuery(
        "select max(o.fechaAsignacion) " +
        "from OrdenReparacion o " +
        "where o.tecnicoAsignado.id = :tecnicoId",
        LocalDateTime.class
      )
      .setParameter("tecnicoId", tecnicoId)
      .uniqueResult();
  }

  @Override
  public List<OrdenReparacion> buscarTodas() {
    return sessionFactory
      .getCurrentSession()
      .createQuery("FROM OrdenReparacion", OrdenReparacion.class)
      .getResultList();
  }

  //--------------Gestion estado y diagnostico("nota tecnica")

  @Override
  public List<OrdenReparacion> listarTodasLasOrdenes() {
    return sessionFactory
      .getCurrentSession()
      .createQuery("from OrdenReparacion", OrdenReparacion.class)
      .getResultList();
  }

  @Override
  public List<OrdenReparacion> buscarPorEmailCliente(String email) {
    return sessionFactory
      .getCurrentSession()
      .createQuery(
        FROM_ORDEN_REPARACION +
        "where o.emailCliente = :email " +
        "order by o.idOrdenReparacion desc",
        OrdenReparacion.class
      )
      .setParameter("email", email)
      .getResultList();
  }

  @Override
  public List<OrdenReparacion> buscarPorTecnico(Long tecnicoId) {
    return sessionFactory
      .getCurrentSession()
      .createQuery(
        FROM_ORDEN_REPARACION +
        "where o.tecnicoAsignado.id = :tecnicoId " +
        "order by o.idOrdenReparacion desc",
        OrdenReparacion.class
      )
      .setParameter("tecnicoId", tecnicoId)
      .getResultList();
  }

  @Override
  public List<OrdenReparacion> buscarOrdenesCompletadasPorTecnico(Long idTecnico) {
    //Completadas refiere a ordenes con estado reparado o entregado
    return sessionFactory
      .getCurrentSession()
      .createQuery(
        "FROM OrdenReparacion o WHERE o.tecnicoAsignado.id = :idTecnico AND o.estado IN (:estadoReparado, :estadoEntregado)",
        OrdenReparacion.class
      )
      .setParameter("idTecnico", idTecnico)
      .setParameter("estadoReparado", EstadoOrden.REPARADO)
      .setParameter("estadoEntregado", EstadoOrden.ENTREGADO)
      .getResultList();
  }
}
