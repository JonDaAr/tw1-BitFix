package com.tallerwebi.presentacion;

import com.tallerwebi.dominio.NivelReparacion;

public class DatosRegistro {

  private String nombre;
  private String apellido;
  private String email;
  private String telefono;
  private String nombreUsuario;
  private String password;
  private String repetirPassword;

  // Getters y Setters
  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getApellido() {
    return apellido;
  }

  public void setApellido(String apellido) {
    this.apellido = apellido;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getTelefono() {
    return telefono;
  }

  public void setTelefono(String telefono) {
    this.telefono = telefono;
  }

  public String getNombreUsuario() {
    return nombreUsuario;
  }

  public void setNombreUsuario(String nombreUsuario) {
    this.nombreUsuario = nombreUsuario;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getRepetirPassword() {
    return repetirPassword;
  }

  public void setRepetirPassword(String repetirPassword) {
    this.repetirPassword = repetirPassword;
  }

  private NivelReparacion nivelSoporte;

  public NivelReparacion getNivelSoporte() {
    return nivelSoporte;
  }

  public void setNivelSoporte(NivelReparacion nivelSoporte) {
    this.nivelSoporte = nivelSoporte;
  }
}
